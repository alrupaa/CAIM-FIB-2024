import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import argparse

def zipf_law(rank, c, a, b):
    return c / (rank + b) ** a

def leer_datos(archivo_entrada):
    with open(archivo_entrada, 'r') as archivo:
        lineas = archivo.readlines()

    pares = []
    for linea in lineas:
        try:
            numero, palabra = linea.strip().split(", ")
            pares.append((int(numero), palabra))
        except ValueError:
            print(f"Línea ignorada debido a un formato incorrecto: {linea.strip()}")

    # Ordenar la lista por número en orden descendente (de mayor a menor)
    pares_ordenados = sorted(pares, key=lambda x: x[0], reverse=True)
    # Extraer los números (frecuencias) y calcular el rango (posición en la lista)
    numeros = [numero for numero, _ in pares_ordenados]
    ranks = np.arange(1, len(numeros) + 1)
    return ranks, numeros

def ajustar_zipf(ranks, numeros):
    c_init = max(numeros)  # Valor máximo de la frecuencia como estimación inicial para c
    a_init = 1.0           # Inicializar a como 1.0
    b_init = 1.0           # Inicializar b como 1.0
    # Ajustar los parámetros de la ley de Zipf a los datos
    popt, _ = curve_fit(zipf_law, ranks, numeros, p0=[c_init, a_init, b_init], maxfev=5000)
    return popt

def graficar_ajuste(ranks, numeros, parametros):
    # Graficar los datos originales
    plt.scatter(ranks, numeros, label='Datos originales', color='blue')

    # Graficar la curva ajustada
    ajuste = zipf_law(ranks, *parametros)
    plt.plot(ranks, ajuste, label=f'Ajuste: c={parametros[0]:.2f}, a={parametros[1]:.2f}, b={parametros[2]:.2f}', color='red')

    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel('Rango (log)')
    plt.ylabel('Frecuencia (log)')
    plt.legend()
    plt.title('Ley de Zipf - Ajuste de Ley de Potencias')
    plt.show()

def analizar_ley_zipf(archivo_entrada):
    ranks, numeros = leer_datos(archivo_entrada)
    
    # Verificar que no haya valores inválidos
    if any(numero <= 0 for numero in numeros):
        print("Error: los números de frecuencia deben ser mayores que cero.")
        return
    
    parametros = ajustar_zipf(ranks, numeros)
    graficar_ajuste(ranks, numeros, parametros)
    print(f"Parámetros de la ley de Zipf: c = {parametros[0]:.4f}, a = {parametros[1]:.4f}, b = {parametros[2]:.4f}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Analiza la ley de Zipf a partir de un archivo.')
    parser.add_argument('archivo', type=str, help='Ruta del archivo de entrada con el formato NUMERO, PALABRA')
    
    args = parser.parse_args()
    analizar_ley_zipf(args.archivo)