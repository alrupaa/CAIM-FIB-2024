import sys
import nltk
nltk.download('punkttab')
nltk.download('wordnet')
from nltk.stem.porter import *
from nltk.corpus import words


if len(sys.argv) != 2:
    print("Uso: python3 filtrado.py <archivo_entrada>")
    sys.exit(1)
archivo_entrada = sys.argv[1]
archivo_salida = archivo_entrada.replace('.txt', '_filtrado.txt')
 
nltk.download('words')
words = set(words.words())

porter_stemmer = PorterStemmer()

with open(archivo_entrada, 'r') as f:
    lineas = f.readlines()


result = []
last_word = ""
last_num = 0
for line in lineas:
    if ',' in line:
        number, word = line.replace("","").replace(" ","").strip().split(',',1)
    else:
        continue
    thisword = porter_stemmer.stem(word)
    if last_word != thisword and int(number) > 30 and word.isalpha() and thisword in words: # 30 es el umbral ajustable
        result.append((number," " + thisword))
    else:
        if last_word == thisword and result != []:
            result.pop()
            result.append((int(number) + int(last_num)," " + thisword))
    last_word = thisword
    last_num = number

print(linea for linea in lineas)

with open(archivo_salida, 'w') as f2:
    for number, word in result:
        f2.write(f"{number},{word}\n")

print(f'Las lineas se han filtrado.')
