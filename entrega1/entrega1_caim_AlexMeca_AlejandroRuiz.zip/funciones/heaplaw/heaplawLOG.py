import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


archivo = 'resultado.txt'
datos = pd.read_csv(archivo, header=None, names=['N', 'F'])

def heap_law(N, k, beta):
    return k * N ** beta

# Ajustar los parámetros k y beta usando curve_fit
N = datos['N'].values
F = datos['F'].values
parametros, _ = curve_fit(heap_law, N, F)

k, beta = parametros

# Imprimir los parámetros ajustados
print(f'Parámetros ajustados: k = {k}, beta = {beta}')

# Graficar los datos originales y la curva ajustada
plt.scatter(N, F, label='Datos originales')
N_fit = np.linspace(min(N), max(N), 100)
F_fit = heap_law(N_fit, k, beta)
plt.xscale('log')
plt.yscale('log')
plt.plot(N_fit, F_fit, color='red', label='Ajuste de la ley de Heap')
plt.xlabel('Número total de palabras (N)')
plt.ylabel('Número de palabras distintas (F)')
plt.legend()
plt.show()
