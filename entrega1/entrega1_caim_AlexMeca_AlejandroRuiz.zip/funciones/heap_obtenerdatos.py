import os
import csv

# Ruta de la carpeta 'textos'
carpeta_textos = 'textos'
resultados = []

# Iterar sobre cada archivo en la carpeta 'textos'
for archivo in os.listdir(carpeta_textos):
    if archivo.endswith('.txt'):
        ruta_archivo = os.path.join(carpeta_textos, archivo)
        n = 0
        f = 0
        
        with open(ruta_archivo, 'r') as f:
            lineas = f.readlines()
            for linea in lineas:
                if linea.startswith("---"):
                    break
                partes = linea.strip().split(',')
                if len(partes) == 2:
                    numero, _ = partes
                    n += int(numero)
            
            # Obtener el valor de la última línea después de '---'
            if lineas:
                ultima_linea = lineas[-1].strip()
                if ultima_linea and ultima_linea.split()[0].isdigit():
                    f = int(ultima_linea.split()[0])
        
        resultados.append((n, f))

# Escribir los resultados en un archivo de salida
with open('resultado/resultados.txt', 'w') as f:
    for n, F in resultados:
        f.write(f"{n},{F}\n")