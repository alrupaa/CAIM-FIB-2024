#!/usr/bin/python

from collections import namedtuple
import time
import sys
import matplotlib.pyplot as plt

damping = 0.85
alfa = 0.00000001 #mirar el valor de alfa optimo
pageRank = []

class Edge:
    def __init__ (self, origin=None):
        self.origin = origin # write appropriate value
        self.weight = 0 # write appropriate value
        self.originIndex = 0

    def __repr__(self):
        return "edge: {0} {1}".format(self.origin, self.weight)
        
    ## write rest of code that you need for this class

class Airport:  #A:  importancia anterior del qeu te apunta * peso con el que te apunta / peso total de salida del qeu te apunta
    def __init__ (self, iden=None, name=None):
        self.code = iden
        self.name = name         
        self.routes = [] #lista de EDGES entrantes 
        self.routeHash = dict() #edge.origin -> edge
        self.outweight = 0  # suma pesos salientes

    def __repr__(self):
        return f"{self.code}\t{self.pageIndex}\t{self.name}"

edgeList = [] # list of Edge
edgeHash = dict() # hash of edge to ease the match
airportList = [] # list of Airport
airportHash = dict() # hash key IATA code -> Airport

def readAirports(fd):
    print("Reading Airport file from {0}".format(fd))
    airportsTxt = open(fd, "r");
    cont = 0
    for line in airportsTxt.readlines():
        a = Airport()
        try:
            temp = line.split(',')
            if len(temp[4]) != 5 :
                raise Exception('not an IATA code')
            a.name=temp[1][1:-1] + ", " + temp[3][1:-1] # name, country
            a.code=temp[4][1:-1] #iata code
        except Exception as inst:
            pass
        else:
            cont += 1
            airportList.append(a)
            airportHash[a.code] = a
    airportsTxt.close()
    print(f"There were {cont} Airports with IATA code")


def readRoutes(fd):
    print("Reading Routes file from {0}".format(fd))
    routesTxt = open(fd,"r")
    for line in routesTxt.readlines():
        e = Edge()
        try:
            temp = line.split(',')
            if len(temp[2]) != 3 or len(temp[4]) != 3 or temp[2] not in airportHash or temp[4] not in airportHash:
                raise Exception('not an IATA code or not a valid route')
        except Exception as inst:
            pass
        else:
            a = edgeHash.get((temp[2], temp[4]), None)
            if a is not None:
                a.weight += 1        
            else:
                e.origin = temp[2]
                e.weight = 1
                e.originIndex = airportList.index(airportHash[temp[2]])
                edgeList.append(e)
                edgeHash[(temp[2],temp[4])] = e
                airportHash[temp[4]].routes.append(e)
                airportHash[temp[4]].routeHash[temp[2]] = e
            airportHash[temp[2]].outweight += 1
    routesTxt.close()
    print(f"There were {len(edgeList)} routes")


def computePageRanks():
    print("Computing PageRanks...")
    n = len(airportList)
    P = [1/n for a in airportList]
    condition =  True
    iterations = 0
    while condition:
        condition = False
        iterations += 1
        Q = [0 for a in airportList]

        for i in range(0, n):
            Q[i] = (1 - damping) / n

        sinSalidas = 0

        for i in range(0, n):
            a = airportList[i]

            if a.outweight == 0:
                sinSalidas += P[i]
            suma = 0
            for edge in a.routes:
                suma += P[edge.originIndex] * edge.weight / airportList[edge.originIndex].outweight
            Q[i] += damping * suma

        for i in range(0, n):
            Q[i] += damping * sinSalidas / n
            if abs(P[i] - Q[i]) > alfa: 
                condition = True

        P = Q
        #print(f"Sum of Q is in iteration {iterations} is {sum(Q)}") #check if the sum of Q is 1

    global pageRank 
    pageRank = P
    return iterations

def outputPageRanks():
    print("Printing PageRanks...")
    sorted_airports = sorted(zip(airportList, pageRank), key=lambda x: x[1], reverse=True)
    for airport, pageRanks in sorted_airports:
        print(f"{airport.code}\t{pageRanks}")

def debug():
    sorted_airports = sorted(zip(airportList, pageRank), key=lambda x: x[1], reverse=True)
    for idx, (airport, _) in enumerate(sorted_airports):
        if len(airport.routes) == 0:
            print(f"{airport.code}\t{idx}")

    total_page_rank = sum(pageRank)
    if abs(total_page_rank - 1.0) > alfa:
        print(f"Warning: Total PageRank is not 1 but {total_page_rank}")
    else:
        print("Total PageRank is correctly equal to 1")
    

def debugAlpha():
    global alfa
    previous_ranks = None
    for i in range(25):
        alfa = 0.1 / (10 ** i)
        start_time = time.time()
        iterations = computePageRanks()
        end_time = time.time()
        current_ranks = [airport.code for airport, _ in sorted(zip(airportList, pageRank), key=lambda x: x[1], reverse=True)]
        if previous_ranks is not None:
            same_position_count = sum(1 for prev, curr in zip(previous_ranks, current_ranks) if prev == curr)
            print(f"Alpha: {0.1}/10^{i}, Iterations: {iterations}, Same position count: {same_position_count}, Time: {end_time - start_time} seconds")
        previous_ranks = current_ranks

def graphSimilar():
    x_values = [
    "0.1 - 0.1/10^1", "0.1/10^1 - 0.1/10^2", "0.1/10^2 - 0.1/10^3", 
    "0.1/10^3 - 0.1/10^4", "0.1/10^4 - 0.1/10^5", "0.1/10^5 - 0.1/10^6",
    "0.1/10^6 - 0.1/10^7", "0.1/10^7 - 0.1/10^8", "0.1/10^8 - 0.1/10^9",
    "0.1/10^9 - 0.1/10^10", "0.1/10^10 - 0.1/10^11", "0.1/10^11 - 0.1/10^12",
    "0.1/10^12 - 0.1/10^13", "0.1/10^13 - 0.1/10^14", "0.1/10^14 - 0.1/10^15",
    "0.1/10^15 - 0.1/10^16", "0.1/10^16 - 0.1/10^17"
    ]
    y_values = [5740, 2453, 2477, 2528, 3732, 5491, 5718, 5740, 5738, 5735, 5733, 5736, 5736, 5736, 5740,5740, 5740]
    plt.figure(figsize=(10, 6))
    plt.plot(x_values, y_values, marker='o')
    plt.xlabel('Alpha values')
    plt.ylabel('Similar positions')
    plt.title('Graph of similar positions between alpha values')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()
    return 0

def graphTime():
    x_values = [
    "0.1", "0.1/10^1", "0.1/10^2", "0.1/10^3", "0.1/10^4", "0.1/10^5", "0.1/10^6", "0.1/10^7", 
    "0.1/10^8", "0.1/10^9", "0.1/10^10", "0.1/10^11", "0.1/10^12", "0.1/10^13", "0.1/10^14", 
    "0.1/10^15", "0.1/10^16", "0.1/10^17"
    ]
    y_values = [0.017328500747680664,0.016665220260620117,0.06575226783752441,0.10853910446166992,0.30102014541625977,0.5298607349395752,0.7883682250976562,0.9512553215026855,1.2075610160827637,1.4364309310913086,1.6125433444976807,1.8208496570587158,2.1083462238311768,2.318769693374634,2.6541545391082764,2.750300407409668,3.235661268234253,3.4624290466308594]

    plt.figure(figsize=(10, 6))
    plt.plot(x_values, y_values, marker='o')
    plt.xlabel('Alpha values')
    plt.ylabel('Time in seconds')
    plt.title('Graph of time at alpha values')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()
    return 0

def graphIterations():
    x_values = [
    "0.1", "0.1/10^1", "0.1/10^2", "0.1/10^3", "0.1/10^4", "0.1/10^5", "0.1/10^6", "0.1/10^7", 
    "0.1/10^8", "0.1/10^9", "0.1/10^10", "0.1/10^11", "0.1/10^12", "0.1/10^13", "0.1/10^14", 
    "0.1/10^15", "0.1/10^16", "0.1/10^17"
    ]
    y_values = [1,1,4,7,20,34,48,63,77,91,105,119,134,148,162,176,190,204]

    plt.figure(figsize=(10, 6))
    plt.plot(x_values, y_values, marker='o')
    plt.xlabel('Alpha values')
    plt.ylabel('Iterations')
    plt.title('Graph of iterations at alpha values')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()
    return 0

def mainProgram():
    time1 = time.time()
    iterations = computePageRanks()
    time2 = time.time()
    outputPageRanks()
    print("#Iterations:", iterations)
    print("Time of computePageRanks():", time2-time1)
    
def main(argv=None):
    readAirports("airports.txt")
    readRoutes("routes.txt")
    mainProgram()
    #debug()
    #debugAlpha()
    #graphSimilar()
    #graphTime()
    #graphIterations()


if __name__ == "__main__":
    sys.exit(main())



